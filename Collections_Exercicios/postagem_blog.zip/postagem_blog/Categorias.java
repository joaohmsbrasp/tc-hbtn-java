public enum Categorias {
    DEVOPS, DESENVOLVIMENTO, DATA_SCIENCE;  
}
